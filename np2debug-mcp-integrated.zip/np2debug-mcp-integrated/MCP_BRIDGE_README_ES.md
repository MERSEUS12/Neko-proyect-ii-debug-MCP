# Puente MCP de NP2Debug (integración inicial)

Esta rama añade `win9x/np2mcp.cpp` y `win9x/np2mcp.h`, y los registra en `np21.vcxproj`. El bucle principal llama a `np2mcp_poll()` en el hilo de emulación y cierra el puente al salir.

## Transporte y seguridad
- TCP solo en `127.0.0.1:8765`.
- Un JSON por línea; no hay ejecución de shell ni acceso arbitrario a archivos.
- `read_memory` solo lectura, límite de 4096 bytes, rango de 2 MiB.
- No se implementa escritura remota de memoria.
- El servicio intenta iniciar al primer ciclo; si el puerto está ocupado, el emulador continúa normalmente sin MCP.

## Métodos actuales
- `status`
- `pause`, `resume`
- `step` (un paso del depurador por solicitud)
- `registers` (registros 80286)
- `read_memory` (hexadecimal)
- `screenshot` (BMP base64 del área cliente)

## Limitaciones y validación necesaria
- No se ha compilado en este entorno: requiere el toolchain Windows/VS2010 y las dependencias del proyecto.
- La captura usa GDI sobre el área cliente de la ventana; se debe verificar que el backend DirectDraw produce una captura fiable en el entorno destino.
- El puente usa un protocolo JSON mínimo para solicitudes controladas; antes de exponer más métodos, se recomienda reemplazar el parser mínimo por uno robusto y añadir pruebas de fuzzing.
- El endpoint es local, no debe exponerse mediante port-forwarding ni firewall.
- El servidor procesa una conexión a la vez y las peticiones se sirven en el hilo de emulación. Mantener las solicitudes pequeñas evita bloquear el bucle.

## Petición de prueba
`{"id":"test1","method":"status","params":{}}`

Respuesta esperada: JSON con `ok:true` y las capacidades del puente.
