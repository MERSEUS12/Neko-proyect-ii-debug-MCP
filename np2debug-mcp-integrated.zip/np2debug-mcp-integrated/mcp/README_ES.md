# Servidor MCP de NP2Debug

1. Instala Python 3.11+ y `pip install -r mcp/requirements.txt`.
2. Ejecuta OpenCode con el servidor MCP local configurado para lanzar `mcp/mcp_server.py`.
3. Inicia el NP2Debug modificado. El puente C++ escucha en `127.0.0.1:8765`.
4. Prueba `np2_status`, `np2_screenshot`, `np2_registers` y `np2_read_memory`.

El emulador y el servidor MCP deben ejecutarse en el mismo PC. No expongas el puerto a la red. El prototipo no permite escritura remota de memoria ni ejecución de comandos del sistema.
