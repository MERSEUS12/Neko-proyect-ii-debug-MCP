"""MCP server for the local NP2Debug bridge."""
from __future__ import annotations
import base64
import json
import os
import socket
from io import BytesIO
from PIL import Image as PILImage
import uuid
from typing import Any
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.utilities.types import Image

HOST = os.getenv("NP2_BRIDGE_HOST", "127.0.0.1")
PORT = int(os.getenv("NP2_BRIDGE_PORT", "8765"))
TIMEOUT = float(os.getenv("NP2_BRIDGE_TIMEOUT", "3.0"))
MAX_RESPONSE = 10 * 1024 * 1024
mcp = FastMCP("np2debug")

class BridgeError(RuntimeError):
    pass

def request(method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {"id": str(uuid.uuid4()), "method": method, "params": params or {}}
    raw = (json.dumps(payload, separators=(",", ":")) + "\n").encode("utf-8")
    if len(raw) > 64 * 1024:
        raise BridgeError("request_too_large")
    try:
        with socket.create_connection((HOST, PORT), timeout=TIMEOUT) as sock:
            sock.settimeout(TIMEOUT)
            sock.sendall(raw)
            data = bytearray()
            while len(data) <= MAX_RESPONSE:
                chunk = sock.recv(16384)
                if not chunk:
                    break
                data.extend(chunk)
                if b"\n" in chunk:
                    break
            if len(data) > MAX_RESPONSE:
                raise BridgeError("response_too_large")
    except OSError as exc:
        raise BridgeError("NP2Debug bridge unavailable. Start the modified NP2Debug build and ensure 127.0.0.1:8765 is free.") from exc
    try:
        response = json.loads(bytes(data).split(b"\n", 1)[0].decode("utf-8"))
    except Exception as exc:
        raise BridgeError("invalid_bridge_response") from exc
    if response.get("id") != payload["id"]:
        raise BridgeError("response_id_mismatch")
    if not response.get("ok"):
        err = response.get("error", {})
        raise BridgeError(f"{err.get('code', 'bridge_error')}: {err.get('message', '')}")
    result = response.get("result", {})
    if not isinstance(result, dict):
        raise BridgeError("invalid_result")
    return result

@mcp.tool()
def np2_status() -> dict[str, Any]:
    """Check emulator connection, paused state, version, and capabilities."""
    return request("status")

@mcp.tool()
def np2_pause() -> dict[str, Any]:
    """Pause the emulator through its debugger controls."""
    return request("pause")

@mcp.tool()
def np2_resume() -> dict[str, Any]:
    """Resume the emulator."""
    return request("resume")

@mcp.tool()
def np2_step() -> dict[str, Any]:
    """Request one debugger step. The emulator must already be paused."""
    return request("step", {"instructions": 1})

@mcp.tool()
def np2_registers() -> dict[str, Any]:
    """Read the emulated 80286 general and segment registers."""
    return request("registers")

@mcp.tool()
def np2_read_memory(address: int, length: int) -> dict[str, Any]:
    """Read up to 4096 bytes from the emulated 2 MiB address space; never writes."""
    if not isinstance(address, int) or address < 0 or address >= 0x200000:
        raise ValueError("address must be in [0, 0x1FFFFF]")
    if not isinstance(length, int) or length < 1 or length > 4096 or address + length > 0x200000:
        raise ValueError("length must be 1..4096 and remain inside the emulated 2 MiB space")
    return request("read_memory", {"address": address, "length": length})

@mcp.tool()
def np2_screenshot() -> Image:
    """Capture the current NP2Debug client area and return it as an image."""
    result = request("screenshot")
    if result.get("mime_type") != "image/bmp":
        raise BridgeError("unexpected_image_type")
    encoded = result.get("bmp_base64", "")
    if not isinstance(encoded, str) or len(encoded) > 8 * 1024 * 1024 * 4 // 3 + 16:
        raise BridgeError("invalid_image_payload")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise BridgeError("invalid_image_base64") from exc
    if not raw.startswith(b"BM"):
        raise BridgeError("invalid_bmp")
    try:
        output = BytesIO()
        PILImage.open(BytesIO(raw)).convert("RGB").save(output, format="PNG")
    except Exception as exc:
        raise BridgeError("bmp_conversion_failed") from exc
    return Image(data=output.getvalue(), format="png")

if __name__ == "__main__":
    mcp.run(transport="stdio")
